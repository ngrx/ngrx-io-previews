import { createSelector, createFeatureSelector } from "@ngrx/store";
import { AppState } from "./app.state";
import { Book } from "../book-list/books.model";

export const selectBooks = createSelector(
  (state: AppState) => state.books,
  (books: ReadonlyArray<Book>) => books
);

export const selectCollectionState = createFeatureSelector<
  ReadonlyArray<string>
>("collection");

const isDefined = <T>(x: T | undefined | null): x is T => {
  return x !== null && x !== undefined;
};

export const selectBookCollection = createSelector(
  selectBooks,
  selectCollectionState,
  (books: ReadonlyArray<Book>, collection: ReadonlyArray<string>) => {
    return collection.map((id) => books.find((book) => book.id === id)).filter(isDefined);
  }
);
